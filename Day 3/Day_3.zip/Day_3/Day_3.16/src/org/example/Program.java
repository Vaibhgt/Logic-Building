package org.example;

import java.util.Scanner;

public class Program {
	public static void main(String[] args) {
		try( Scanner sc = new Scanner(System.in)){
			System.out.print("Enter number	:	");
			System.out.println("Reversed Number	:	"+Integer.parseInt(new StringBuilder(String.valueOf(sc.nextInt())).reverse().toString()));
		}
	}
	public static void main1(String[] args) {
		try( Scanner sc = new Scanner(System.in)){
			System.out.print("Enter number	:	");
			int num1 = sc.nextInt();
			String s1 = String.valueOf(num1);
			StringBuilder sb1 = new StringBuilder(s1);
			sb1.reverse();
			String s2 = sb1.toString();
			int num2 = Integer.parseInt(s2);
			System.out.println("Reversed Number	:	"+num2);
		}
	}
}
