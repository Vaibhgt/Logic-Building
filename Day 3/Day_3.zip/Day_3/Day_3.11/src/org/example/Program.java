package org.example;

public class Program {
	public static void main(String[] args) {
		String s1 = "CDACMumbai";
		String str = "CDAC";
		String s2 = ( str + "Mumbai" ).intern();	//Non Constant expression
		
		if( s1 == s2 )  
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main10(String[] args) {
		String s1 = "CDACMumbai";
		String str = "CDAC";
		String s2 = str + "Mumbai";	//Non Constant expression
		
		if( s1.equals(s2) )  
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main9(String[] args) {
		String s1 = "CDACMumbai";
		String str = "CDAC";
		String s2 = str + "Mumbai";	//Non Constant expression
		
		if( s1 == s2 )  
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Not Equal
	}
	public static void main8(String[] args) {
		String s1 = "CDAC" + "Mumbai";
		//String s1 = "CDACMumbai";
		String s2 = "CDACMumbai";
		if( s1.equals(s2) )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main7(String[] args) {
		String s1 = "CDAC" + "Mumbai";	//Constant expression
		//String s1 = "CDACMumbai";
		String s2 = "CDACMumbai";
		if( s1 == s2 )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main6(String[] args) {
		String s1 = "CDAC";
		String s2 = "CDAC";
		if( s1.equals(s2) )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main5(String[] args) {
		String s1 = "CDAC";
		String s2 = "CDAC";
		if( s1 == s2 )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main4(String[] args) {
		String s1 = new String("CDAC");
		String s2 = "CDAC";
		if( s1.equals(s2))
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main3(String[] args) {
		String s1 = new String("CDAC");
		String s2 = "CDAC";
		if( s1 == s2)
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Not Equal
	}
	public static void main2(String[] args) {
		String s1 = new String("CDAC");
		String s2 = new String("CDAC");
		if( s1.equals(s2))
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main1(String[] args) {
		String s1 = new String("CDAC");
		String s2 = new String("CDAC");
		if( s1 == s2 )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Not Equal
	}
}
