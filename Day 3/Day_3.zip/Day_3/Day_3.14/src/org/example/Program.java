package org.example;

public class Program {
	public static void main(String[] args) {
		String s1 = "CDAC";
		StringBuffer s2 = new StringBuffer("CDAC");
		if( s1.equals( s2 ) )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");	
		//Not Equal
	}
	public static void main3(String[] args) {
		StringBuffer sb1 = new StringBuffer("CDAC");
		StringBuffer sb2 = new StringBuffer("CDAC");
		
		System.out.println(sb1.hashCode());
		System.out.println(sb2.hashCode());
	}
	public static void main2(String[] args) {
		StringBuffer sb1 = new StringBuffer("CDAC");
		StringBuffer sb2 = new StringBuffer("CDAC");
		if( sb1.equals(sb2) )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Not Equal
	}
	public static void main1(String[] args) {
		StringBuffer sb1 = new StringBuffer("CDAC");
		StringBuffer sb2 = new StringBuffer("CDAC");
		if( sb1 == sb2 )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Not Equal
	}
}
