package org.example;

public class Program {
	public static void main(String[] args) {
		String str = "public static void main(String[] args)";
		String subStr = str.substring(19,23);
		System.out.println(subStr);
	}
	public static void main1(String[] args) {
		String str = "public static void main(String[] args)";
		String subStr = str.substring(19);
		System.out.println(subStr);
	}
}
