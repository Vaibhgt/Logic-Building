package org.example;

public class Program {
	public static void main(String[] args) {
		String s1 = "CDAC";
		StringBuilder s2 = new StringBuilder("CDAC");
		if( s1.equals(s2) )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Not Equal
	}
	public static void main2(String[] args) {
		StringBuilder sb1 = new StringBuilder("CDAC");
		StringBuilder sb2 = new StringBuilder("CDAC");
		if( sb1.equals(sb2) )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Not Equal
	}
	public static void main1(String[] args) {
		StringBuilder sb1 = new StringBuilder("CDAC");
		StringBuilder sb2 = new StringBuilder("CDAC");
		if( sb1 == sb2 )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Not Equal
	}
}
