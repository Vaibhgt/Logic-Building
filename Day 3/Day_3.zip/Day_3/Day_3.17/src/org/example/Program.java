package org.example;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Program {
	public static void main(String[] args) {
		try( BufferedReader reader  = new BufferedReader(new FileReader(new File("books.xml")))){
			StringBuilder response = new StringBuilder();
			String line = null;
			while( ( line = reader.readLine( ) ) != null ) {
				response.append(line);
			}
			System.out.println(response.toString());
		}catch( Exception ex ) {
			ex.printStackTrace();
		}
	}
}
