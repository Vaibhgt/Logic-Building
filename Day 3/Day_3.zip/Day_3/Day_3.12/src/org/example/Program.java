package org.example;

import java.util.StringTokenizer;

public class Program {
	public static void main(String[] args) {
		String str = "ab+bc* cd-de/ef";
		StringTokenizer stk = new StringTokenizer(str,"-*+/", true);
		
		while( stk.hasMoreTokens()) {
			String token = stk.nextToken();
			System.out.println(token);
		}
	}
	public static void main6(String[] args) {
		String str = "ab+bc*cd-de/ef";
		StringTokenizer stk = new StringTokenizer(str,"+*-/");
		
		while( stk.hasMoreTokens()) {
			String token = stk.nextToken();
			System.out.println(token);
		}
	}
	public static void main5(String[] args) {
		String str = "www.cdac.in";
		StringTokenizer stk = new StringTokenizer(str,".");
		
		while( stk.hasMoreTokens()) {
			String token = stk.nextToken();
			System.out.println(token);
		}
	}
	public static void main4(String[] args) {
		String str = "public static void main";
		StringTokenizer stk = new StringTokenizer(str);
		
		/* while( stk.hasMoreElements()) {
			String token = (String) stk.nextElement();
			System.out.println(token);
		} */
		
		while( stk.hasMoreTokens()) {
			String token = stk.nextToken();
			System.out.println(token);
		}
	}
	public static void main3(String[] args) {
		String str = "public static void main";
		StringTokenizer stk = new StringTokenizer(str);
		System.out.println("Tokens	:	"+stk.countTokens());	//Tokens	:	4
	}
	public static void main2(String[] args) {
		String str = "public static void main";
		String regex = " ";
		String[] words = str.split( regex );
		for (String word : words) {
			System.out.println(word);
		}
	}
	public static void main1(String[] args) {
		int num1 = 10;
		
		String str = String.valueOf(num1);
		System.out.println(str);
		
		int num2 = Integer.parseInt(str);
		System.out.println("Num2	:	"+num2);
	}
}
