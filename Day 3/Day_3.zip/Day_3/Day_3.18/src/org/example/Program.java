package org.example;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Program {
	public static void main(String[] args) {
		StringBuilder sb1 = new StringBuilder("CDAC");
		StringBuilder sb2 = sb1;
	}
	public static void main2(String[] args) {
		for( int count = 2304; count <= 2431; ++ count ) {
			System.out.print((char)count+" ");
		}
		System.out.println();
	}
	public static void main1(String[] args) {
		Date date = new Date(122, 1, 28);
		//SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMMM-yyyy");
		String strDate = sdf.format(date);
		System.out.println(strDate);
	}
}