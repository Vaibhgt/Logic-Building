package org.example;

import java.util.Objects;

class Employee{	//class Employee extends Object{
	private String name;
	private int empid;
	private float salary;
	public Employee(String name, int empid, float salary) {
		this.name = name;
		this.empid = empid;
		this.salary = salary;
	}
	//Employee this = emp1
	//Object obj = emp1;	//Upcasting
//	@Override
//	public boolean equals(Object obj) {
//		if( obj != null ) {
//			Employee other = (Employee) obj;	//Downcasting
//			if( this.empid == other.empid )
//				return true;
//		}
//		return false;
//	}
	@Override
	public int hashCode() {
		return Objects.hash(empid);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return empid == other.empid;
	}
}
public class Program {
	public static void main(String[] args) {
		Employee emp1 = new Employee("Sandeep", 1789, 45000.50f);
		Employee emp2 = new Employee("Sandeep", 1789, 45000.50f);
		if( emp1 != null && emp1.equals(emp2) )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main4(String[] args) {
		Employee emp1 = new Employee("Sandeep", 1789, 45000.50f);
		Employee emp2 = new Employee("Sandeep", 1789, 45000.50f);
		if( emp1 == emp2 )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Not Equal
	}
	public static void main3(String[] args) {
		int num1 = 10;
		int num2 = 10;
		if( num1 == num2)	//OK
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	public static void main2(String[] args) {
		Integer num1 = new Integer(10);
		Integer num2 = new Integer(10);
		if( num1.equals(num2))	//OK
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		//Equal
	}
	/* public static void main1(String[] args) {
		int num1 = 10;
		int num2 = 10;
		if( num1.equals(num2))	//Cannot invoke equals(int) on the primitive type int
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
	} */
}
