package org.example;

import p1.C1;
import p1.C2;
import p1.C3;
import p2.C4;
import p2.C5;

public class Program {
	public static void main(String[] args) {
		//C1 c1 = new C1( );
		//c1.f1();
		
		//C2 c2 = new C2();
		//c2.f2();
		
		//C3 c3 = new C3();
		//c3.f3();
		
		//C4 c4 = new C4();
		//c4.f4();
		
		C5 c5 = new C5();
		c5.f5();
	}
}
