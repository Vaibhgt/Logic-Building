package org.example;

public class Program {
	public static void main(String[] args) {
		String str = "Pune";
		int pinCode = 411046;
		//str.concat(pincode);	//Not OK
		//String res = str.concat(String.valueOf(pinCode));	//OK
		String res = str + pinCode;	//OK
		System.out.println(res);
	}
	public static void main4(String[] args) {
		String s1 = "CDAC";
		String s2 = "Mumbai";
		String s3 =  s1.concat(s2);
		
		System.out.println(s1);	//CDAC
		System.out.println(s2);	//Mumbai
		System.out.println(s3);	//CDACMumbai
	}
	public static void main3(String[] args) {
		//String str = "CDAC";
		
		char[] data = { 'C','D','A','C'};
		String str = new String( data );
		System.out.println(str);
	}
	public static void main2(String[] args) {
		String str = "CDAC";
		str = str + "Mumbai";
		System.out.println(str);
	}
	public static void main1(String[] args) {
		String str = "CDAC";	
		System.out.println("Length	:	"+str.length());	//4
		
		char ch = str.charAt(4);	//StringIndexOutOfBoundsException
		System.out.println("Char	:	"+ch);
	}
}
